Iron Room — Original Groove Library

2,375 programmed patterns; 103,835 notes.
50 new style-specific collections plus the original 36 starter entries.
Each MIDI file carries suggested BPM, time signature, velocity and timing.
Use standard GM percussion mapping. Semi-open hi-hat = 46; fully open = 26.
Original MIDI and application code: MIT. No GGD MIDI is included.
These are original deterministic arrangements built from authored style recipes,
not recorded performances. World rhythms are acoustic drum-kit adaptations.

Browse, preview and edit in Iron Room. Every pattern is editable.
